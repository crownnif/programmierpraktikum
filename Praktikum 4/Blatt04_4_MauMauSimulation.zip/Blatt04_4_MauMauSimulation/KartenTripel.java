import spielkarten.Spielkarte; 

/**
 * Beschreiben Sie hier die Klasse KartenTripel.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class KartenTripel
{
    // Instanzvariablen - ersetzen Sie das folgende Beispiel mit Ihren Variablen
    private Spielkarte _spielkarte1;
    private Spielkarte _spielkarte2;
    private Spielkarte _spielkarte3;

    /**
     * Konstruktor für Objekte der Klasse KartenTripel
     */
    public KartenTripel(Spielkarte k1, Spielkarte k2, Spielkarte k3)
    {
        _spielkarte1 = k1;
        _spielkarte2 = k2;
        _spielkarte3 = k3;
    }
    
    public KartenTripel()
    {
        _spielkarte1 = null;
        _spielkarte2 = null;
        _spielkarte3 = null;
    }

    /**
     * Gibt die erste Karte.
     * 
     * @return        die erste Karte
     */
    public Spielkarte karte1()
    {
        return _spielkarte1;
    }
    
    /**
     * Gibt die zweite Karte.
     * 
     * @return        die zweite Karte
     */
    public Spielkarte karte2()
    {
        return _spielkarte2;
    }
    
    /**
     * Gibt die dritte Karte.
     * 
     * @return        die dritte Karte
     */
    public Spielkarte karte3()
    {
        return _spielkarte3;
    }
    
    public void  fuegeHinzu(Spielkarte spielkarte)
    {
        if(_spielkarte1 == null)
        {
            _spielkarte1 = spielkarte;
        }
        else if(_spielkarte2 == null)
        {
            _spielkarte2 = spielkarte;
        }
        else if(_spielkarte3 == null)
        {
            _spielkarte3 = spielkarte;
        }
    }
    
    public boolean istVoll()
    {
        return karte1() != null
        && karte2() != null
        && karte3() != null;
    }
}
