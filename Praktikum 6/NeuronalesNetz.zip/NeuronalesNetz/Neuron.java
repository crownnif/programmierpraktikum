
/**
 * Interface Neuron
 * 
 * @author Finn K.
 * @version 2022
 */

public interface Neuron
{
    /**
     * Gibt den Ausgangsstring des Neurons.
     */
    String getAusgangswert();
}
