package spielkarten;


/**
 * Die möglichen Farben einer Spielkarte als Aufzählung.
 *  
 * @author  Axel Schmolitzky
 * @version 2021
 */
public enum Kartenfarbe
{
    KARO, HERZ, PIK, KREUZ
}
