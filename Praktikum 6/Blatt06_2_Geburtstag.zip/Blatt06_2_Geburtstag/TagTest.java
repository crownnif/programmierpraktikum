import static org.junit.Assert.*;

import org.junit.Test;
/**
 * The test class TagTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class TagTest
{
    /**
     * Testet, ob zwei Tag-Exemplare, die denselben Tag repraesentieren,
     * als gleich angesehen werden.
     */
    @Test
    public void testGleichheit()
    {
    }
    
    /**
     * Testet, ob zwei Tag-Exemplare, die verschiedene Tage repraesentieren,
     * als ungleich angesehen werden.
     */
    @Test
    public void testUngleichheit()
    {
    }
}
